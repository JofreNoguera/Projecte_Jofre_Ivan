import tkinter as tk
from tkinter import messagebox
from tkinter import filedialog
ventana = tk.Tk()
ventana.title("Projecte Python 2023-2024 | Jofre i Ivan")

# Crear una etiqueta
etiqueta = tk.Label(ventana)
etiqueta.pack(padx=100, pady=100) # Añadir la etiqueta a la ventana
# Iniciar el bucle de eventos
def registrar_usuario(nom_entry):
    # Crear un archivo con el nombre del usuario
    nombre_archivo = f"{nom_entry}.txt"
    with open(f"perfils/{nombre_archivo}", "w") as archivo:
        archivo.write("Informació de l'usuari:\n")
        archivo.write(f"Nombre de usuario: {nom_entry}\n")
        archivo.write(f"Contrasenya de usuari: {contra_entry}")


fitxer = open("usuaris/usuaris.txt", "r")
nom = tk.Label(ventana, text="Usuari: ")
nom.pack()

nom_entry = tk.Entry(ventana)
nom_entry.pack()

contra = tk.Label(ventana, text="Contrasenya: ")
contra.pack()

contra_entry = tk.Entry(ventana)
contra_entry.pack()

login = tk.Button(ventana, text="Login", command=registrar_usuario)
login.pack()


ventana.mainloop()
